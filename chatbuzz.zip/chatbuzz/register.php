<!--html code for the registration page, styling the registration page-->

<!DOCTYPE html>
<html>
 	<head>
  		<script src="http://code.jquery.com/jquery-1.9.0.min.js"></script>
  		<script src="form.js"></script>
  		<link href="form.css" rel="stylesheet" />
 	</head>
<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#404040">
<tr>
<form name="form1" method="post" action="register_newuser.php">
<td>
<img src="images/chatbuzz.png" alt="Mountain View" style="width: 300px;height:120px" align ="center">
<table width="100%" border="0" cellpadding="4" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<td colspan="3"><strong><font color="black" align="center">Member Login</font></strong></td>
</tr> 
<tr>
<td width="78"><font color="black">Username</font></td>
<td width="6">:</td>
<td width="294"><input name="myusername" type="text" id="myusername"></td>
</tr>
<tr>
<td><font color="black">Password</font></td>
<td>:</td>
<td><input name="mypassword" type="password" id="mypassword"></td>
</tr>
<tr>
<tr>
<td><font color="black">Repeat Password</font></td>
<td>:</td>
<td><input name="repeatmypassword" type="password" id="repeatmypassword"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" value="Register now"></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
</html>

